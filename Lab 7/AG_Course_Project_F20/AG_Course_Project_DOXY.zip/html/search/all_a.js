var searchData=
[
  ['update_5fcirc_5freadindex_79',['update_circ_readindex',['../ble_8c.html#a75650c78ca344c056f398f92d0d7d56e',1,'ble.c']]],
  ['update_5fcirc_5fwrtindex_80',['update_circ_wrtindex',['../ble_8c.html#ae059df3ee946d09f3c849b2d38a90ab3',1,'ble.c']]]
];
