var searchData=
[
  ['enter_5fsleep_19',['enter_sleep',['../sleep__routines_8c.html#a38dae68379e12eee7b465eac207d9e27',1,'sleep_routines.c']]]
];
