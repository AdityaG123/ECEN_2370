var app_8c =
[
    [ "app_peripheral_setup", "app_8c.html#ab8cdb39575ad0f98ace1c6fbd9c54b83", null ]
];