var searchData=
[
  ['cmu_2ec_9',['cmu.c',['../cmu_8c.html',1,'']]],
  ['cmu_5fopen_10',['cmu_open',['../cmu_8c.html#a0bf9288af36bde6e21cc7c79382fff11',1,'cmu.c']]],
  ['current_5fblock_5fenergy_5fmode_11',['current_block_energy_mode',['../sleep__routines_8c.html#a6543cf1ae0de352b82e80ec95be89727',1,'sleep_routines.c']]]
];
